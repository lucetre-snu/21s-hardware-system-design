#ifndef _FPGA_API_H_
#define _FPGA_API_H_
#include <sys/types.h>
#include <vector>

// matrix vector multiplicator
// matrix M: M_SIZE by V_SIZE
// vector V: V_SIZE
// output = M * V

class FPGA
{

private:
  int fd_;
  unsigned int *data_CDMA_pa;
  float *data_BRAM_pa;
  float *data_noncache_pa;
  unsigned int *data_CDMA;
  float *data_BRAM;
  float *data_noncache;
  float *data_MV, *data_MM;
  unsigned int *output_;
  unsigned int *output_M;
  unsigned int *output_MV;

  int m_size_;
  int v_size_;
  int m1_size_; // matrix matrix multiplication first matrix size
  int m2_size_; // matrix matrix multiplication second matrix size

  int need_to_transfer_m1;

  int data_size_MV;
  int data_size_MM;
  int num_block_call_;

public:
  FPGA(off_t data_CDMA_addr_pa, off_t data_noncache_addr_pa,
    off_t data_BRAM_addr_pa, off_t output_addr, int m_size, int v_size);
  ~FPGA();

  // return internal pointer for the data
  float *matrix(void);
  float *vector(void);
  float *matrix_M1(void);
  float *matrix_M2(void);
  void reset(void);
  int num_block_call(void);

  // perform matrix multiplication and return output array pointer
  const float *blockMV();
  const float *blockMM();

  void doCDMA(const float *src, const float *dst, const unsigned int size);

  // Input vector size: num_input
  // Matrix size: num_output * num_input
  // Output vector size: num_output
  // O = M * I
  void largeMV(const float *mat, const float *input, float *output, int num_input, int num_output);
  void largeMM(const float *mat, const float *input, float *output, int num_input, int num_output, int num_matrix);
  void convLowering(const std::vector<std::vector<std::vector<std::vector<float>>>> &cnn_weights,
                    std::vector<std::vector<float>> &new_weights,
                    const std::vector<std::vector<std::vector<float>>> &inputs,
                    std::vector<std::vector<float>> &new_inputs);
};
#endif
