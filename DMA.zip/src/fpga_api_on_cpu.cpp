#include"fpga_api.h"
#include<stdio.h>
#include<iostream>
#include<cstring>

using namespace std;

#define min(x,y) (((x)<(y))?(x):(y))

FPGA::FPGA(off_t data_CDMA_addr, off_t data_DRAM_addr_,
  off_t data_BRAM_addr_, off_t output_addr, int m_size, int v_size)
{
  m_size_ = m_size;
  v_size_ = v_size;

  m1_size_ = v_size * v_size;
  m2_size_ = v_size * v_size;
  data_size_MV = (m_size_+1)*v_size_; // fpga bram data size
  data_size_MM = (v_size_+v_size_)*v_size_; // for Matrix matrix multiplication

  output_ = new unsigned int[m_size_];    // use output_ as tempolar output
  output_M = new unsigned int[v_size_*v_size_];

  data_MV = new float[data_size_MV];	
  data_MM = new float[data_size_MM]; // for Matrix matrix multiplication

  num_block_call_ = 0;
}

FPGA::~FPGA()
{
  // delete[] output_;
  delete[] output_M;
  // delete[] data_MV;
  delete[] data_MM;
}

float* FPGA::matrix(void)
{
  return data_MV + v_size_;
}

float* FPGA::vector(void)
{
  return data_MV;
}

float* FPGA::matrix_M1(void)
{
  return data_MM;
}

float* FPGA::matrix_M2(void)
{
  return data_MM + m1_size_;
}

void FPGA::reset(void)
{
  num_block_call_ = 0;
}

int FPGA::num_block_call(void)
{
  return num_block_call_;
}

const float* FPGA::blockMM()
{
  num_block_call_ += 1;

  // cpu version
  float* m1 = this->matrix_M1();
  float* m2 = this->matrix_M2();
  float* out  = reinterpret_cast<float*>(output_M);  

  for(int i = 0; i < v_size_; ++i)
  {
    for(int j = 0; j < v_size_; ++j){    
      out[v_size_*i+j] = 0;
      for(int k = 0; k < v_size_; ++k){
        out[v_size_*i+j] += m1[v_size_*i+k] * m2[v_size_*k + j];
      }
    }
  }

  for(int i = 0; i < m1_size_; ++i)
    data_MM[i] = out[i];

  return data_MM;    
}

const float* FPGA::blockMV()
{
  num_block_call_ += 1;

  // cpu version
  float* vec = this->vector();
  float* mat = this->matrix();
  float* out  = reinterpret_cast<float*>(output_);  

  for(int i = 0; i < m_size_; ++i)
  {
    out[i] = 0;
    for(int j = 0; j < v_size_; ++j)
      out[i] += vec[j] * mat[v_size_*i + j];
  }

  for(int i = 0; i < m_size_; ++i)
    data_MV[i] = out[i];

  return data_MV;    
}

void FPGA::largeMM(const float* weight_mat, const float* input_mat, float* output, int num_input, int num_output, int num_matrix2)
{
  // weight_mat : T[num_output, num_input]
  // input_mat  : T[num_input, num_matrix2]
  // output = matmul(weight_mat, input_mat) : T[num_output, num_matrix2]
  float* m1 = this->matrix_M1();
  float* m2 = this->matrix_M2();

  // 0) Initialize output vector		
  for(int i = 0; i < num_output*num_matrix2; ++i)
    output[i] = 0;

  for(int i = 0; i < num_output; i += v_size_)
  {
    for(int j = 0; j < num_input; j += v_size_)
    {			
      for(int k = 0; k < num_matrix2; k += v_size_)
      {
        int block_row = min(v_size_, num_output-i);
        int block_col_1 = min(v_size_, num_input-j);
        int block_col_2 = min(v_size_, num_matrix2-k);

        // 1) Assign a m1
        for (int x = 0; x < v_size_; x++)
        {
          for (int y = 0; y < v_size_; y++)
          {
            int index = x * v_size_ + y;
            if (x < block_row && y < block_col_1)
              m1[index] = weight_mat[(i + x) * num_input + (j + y)];
            else
              m1[index] = 0;
          }
        }

        // 2) Assign a m2
        for (int x = 0; x < v_size_; x++)
        {
          for (int y = 0; y < v_size_; y++)
          {
            int index = x * v_size_ + y;
            if (x < block_col_1 && y < block_col_2)
              m2[index] = input_mat[(j + x) * num_matrix2 + (k + y)];
            else
              m2[index] = 0;
          }
        }

        // 3) Call a function `blockMM() to execute Matrix matrix multiplication
        const float* ret = this->blockMM();

        // 4) Accumulate intermediate results
        for(int n = 0; n<block_row; ++n)
        {
          for(int m = 0; m<block_col_2; ++m)
          {
            output[(i + n) + (k + m)*num_output] += ret[n*v_size_ + m];
          }
        }
      }
    } 
  }
}

void FPGA::largeMV(const float* large_mat, const float* input, float* output, int num_input, int num_output)
{
  float* vec = this->vector();
  float* mat = this->matrix();

  // 0) Initialize output vector		
  for(int i = 0; i < num_output; ++i)
    output[i] = 0;

  for(int i = 0; i < num_output; i += m_size_)
  {
    for(int j = 0; j < num_input; j += v_size_)
    {
      // 0) find the dimensions
      int block_row = min(m_size_, num_output-i);
      int block_col = min(v_size_, num_input-j);
      
      // 1) Assign a vector
      for (int c = 0; c < v_size_; c++){
        if (c < block_col)
          vec[c] = input[j+c];
        else
          vec[c] = 0;
      }
      // 2) Assign a matrix
      for (int r = 0; r < m_size_; r++){
        for (int c = 0; c < v_size_; c++){
          int index = v_size_ * r + c;
          if (r < block_row && c < block_col)
            mat[index] = large_mat[(i + r) * num_input + (j + c)];
          else
            mat[index] = 0;
        }
      }
      // 3) Call a function `blockMV() to execute MV multiplication
      const float* ret = this->blockMV();

      // 4) Accumulate intermediate results
      for(int row = 0; row < block_row; ++row)
        output[i + row] += ret[row];
    }
    exit(0);
  }
}

void FPGA::convLowering(const std::vector<std::vector<std::vector<std::vector<float>>>>& cnn_weights,
    std::vector<std::vector<float>>& new_weights,
    const std::vector<std::vector<std::vector<float>>>& inputs,
    std::vector<std::vector<float>>& new_inputs) {
  /*
   * Arguments:
   *
   * conv_weights: [conv_channel, input_channel, conv_height, conv_width]
   * new_weights: [conv_channel,
   *               input_channel * conv_height * conv_width]
   * inputs: [input_channel, input_height, input_width]
   * new_inputs: [input_channel * conv_height * conv_width,
   *              (input_height - conv_height + 1) * (input_width - conv_width + 1)]
   *
   */

  int conv_channel = cnn_weights.size();
  int input_channel = cnn_weights[0].size();
  int conv_height = cnn_weights[0][0].size();
  int conv_width = cnn_weights[0][0][0].size();
  //int input_channel = cnn_weights.size();
  int input_height = inputs[0].size();
  int input_width = inputs[0][0].size();

  // IMPLEMENT THIS
  // For example,
  // new_weights[0][0] = cnn_weights[0][0][0][0];
  // new_inputs[0][0] = inputs[0][0][0];
  
  for (int i=0; i<conv_channel; i++){

    int row_index = 0; //move from 0 to input_channel * conv_height * conv_weight - 1, for each row

    for (int j=0; j<input_channel; j++){
      for (int k=0; k<conv_height; k++){
        for (int l=0; l<conv_width; l++){
          new_weights[i][row_index++]  = cnn_weights[i][j][k][l];
        }
      }
    }
  }

  int h_stride = input_width - conv_width + 1;    //number of horizontal stride
  int v_stride = input_height - conv_height + 1;   //number of vertical stride
  int total_stride = h_stride * v_stride; // total stride = width of new input = (hstride) * (vstride)
  
  for (int i=0; i<total_stride; i++){
    // let (x, y) the top-left point of i-th convolution rectangle 
    int x = i/h_stride;
    int y = i%h_stride; 
    int col_index = 0; //move from 0 to input_channel * conv_height * conv_weight - 1, for each column 

    for (int j=0; j<input_channel; j++){
      for (int k=0; k<conv_height; k++){
        for (int l=0; l<conv_width; l++){
          new_inputs[col_index++][i] = inputs[j][x+k][y+l];
        }
      }
    }
  }

}
